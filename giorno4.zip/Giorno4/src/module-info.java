/**
 * 
 */
/**
 * @author feder
 *
 */
module Giorno4 {
}