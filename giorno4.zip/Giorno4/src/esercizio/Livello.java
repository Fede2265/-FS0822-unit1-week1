package esercizio;

public enum Livello {
	OPERAIO,
	IMPIEGATO, 
	QUADRO, 
	DIRIGENTE
}