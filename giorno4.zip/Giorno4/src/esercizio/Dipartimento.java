package esercizio;

public enum Dipartimento {

	PRODUZIONE, 
	AMMINISTRAZIONE, 
	VENDITE
}