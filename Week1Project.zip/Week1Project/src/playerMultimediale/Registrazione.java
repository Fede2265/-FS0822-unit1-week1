package playerMultimediale;

public class Registrazione extends ElementoMultimediale implements Riproducibile {

	
	private int durata;
	private int volume;

	
	public Registrazione(String titolo) {
		super(titolo);
		this.durata = ElementoMultimediale.def;
		this.volume = ElementoMultimediale.def;
	}
	public Registrazione(String titolo, int durata, int volume) {
		super(titolo);
		this.durata = durata;
		this.volume = volume;
	}

	
	public int getDurata() {
		return durata;
	}
	public int getVolume() {
		return volume;
	}

	
	public void setDurata(int durata) {
		this.durata = durata;
	}
	public void setVolume(int volume) {
		this.volume = volume;
	}

	
	public int abbassaVolume() {
		return this.volume--;
	}
	public int alzaVolume() {
		return this.volume--;
	}
	public void esegui() {
		play();
	}
	public void play() {
		for (int i = 1; i <= durata; i++) {
			System.out.println( i + "  Hai eseguito l'elemento nome: " + getTitolo() + " volume: " + "!".repeat(this.volume) + " durata: " + this.durata + "s");
		};
	}

}
