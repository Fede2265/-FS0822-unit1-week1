package playerMultimediale;

public abstract class ElementoMultimediale {
//	Valore default
	static int def = 5;
//	Proprietà
	private String titolo;
//	Costruttore
	public ElementoMultimediale(String titolo) {
		this.titolo = titolo;
	}

	
	public String getTitolo() {
		return titolo;
	}

	
	protected void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	
	abstract public void esegui();
}
