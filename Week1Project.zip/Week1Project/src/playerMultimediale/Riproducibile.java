package playerMultimediale;

public interface Riproducibile {
	void play();
	int abbassaVolume();
	public int alzaVolume();
}
