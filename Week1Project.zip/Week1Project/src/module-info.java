/**
 * 
 */
/**
 * @author feder
 *
 */
module Week1Project {
}