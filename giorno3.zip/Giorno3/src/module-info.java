/**
 * 
 */
/**
 * @author feder
 *
 */
module Giorno3 {
}