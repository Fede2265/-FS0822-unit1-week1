package es3;

public class es3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner myObj = new Scanner(System.in);
		System.out.println("Enter a string: ");
		String string = myObj.nextLine();
		
		myObj.close();
		
		String esc = ":q";
		int i = 0;
		
		while(!string.equals(esc) && i<string.length()) {
			System.out.print(string.charAt(i) + ", ");
            i++;
        }
	}
