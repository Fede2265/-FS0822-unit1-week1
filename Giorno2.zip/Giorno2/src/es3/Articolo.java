package es3;

public class Articolo {
	
	int code;
	String description;
	double price;
	int stack;
	
	public Articolo(int code, String description, double price, int stack) {
		this.code = code;
		this.description = description;
		this.price = price;
		this.stack = stack;
	}
	
}