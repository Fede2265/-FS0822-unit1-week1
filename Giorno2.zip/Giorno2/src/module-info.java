/**
 * 
 */
/**
 * @author feder
 *
 */
module Giorno2 {
}