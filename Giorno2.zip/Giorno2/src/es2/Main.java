package es2;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner myObj = new Scanner(System.in);
		
		String num = "3421667194";
		
		double h = 0.0;
		
		Sim person1 = new Sim(num, h);
		person1.chiamate[0] = "0000000000";
		person1.chiamate[1] = "1111111111";
		person1.chiamate[2] = "2222222222";
		person1.chiamate[3] = "3333333333";
		person1.chiamate[4] = "4444444444";

		System.out.println(person1.Stampa());
		
		System.out.println("Inserisci la ricarica che vuoi effettuare:");
		double ric = myObj.nextDouble();
		
		System.out.println( "Dopo la ricarica il tuo credito ammonta a: " + person1.Credito(ric) + " euro");
		
		

	}

}